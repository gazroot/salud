# Salud en Orden — prototipo funcional

## Cómo probarlo
1. Descomprime la carpeta.
2. Abre `index.html` en un navegador moderno o publica la carpeta en un hosting estático.
3. Desde Inicio puedes registrar medidas y citas. Medicamentos y Órdenes permiten añadir/eliminar registros. Ajustes guarda tu perfil y contacto de emergencia.
4. En Ajustes puedes exportar una copia JSON o borrar los datos guardados.

## Importante
Esta primera versión guarda la información en `localStorage` del navegador y no tiene cuenta, sincronización ni base de datos en la nube. No la uses para guardar datos médicos sensibles o como sistema clínico definitivo. Para sincronizar dispositivos habrá que conectar una base de datos como Supabase con autenticación y políticas de acceso privado. Los valores médicos de ejemplo del diseño original no deben interpretarse como mediciones reales.
